/*
 * Copyright © 2022  Google, Inc.
 *
 *  This is part of HarfBuzz, a text shaping library.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN
 * IF THE COPYRIGHT HOLDER HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 *
 * THE COPYRIGHT HOLDER SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING,
 * BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE COPYRIGHT HOLDER HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * Google Author(s): Garret Rieger
 */

#include "graph.hh"
#include "../hb-ot-layout-common.hh"
#include "graph-result.hh"

#ifndef GRAPH_CLASSDEF_GRAPH_HH
#define GRAPH_CLASSDEF_GRAPH_HH

namespace graph {

struct ClassDefFormat1 : public OT::ClassDefFormat1_3<SmallTypes>
{
  graph_result_t<void> sanitize (const graph_t::vertex_t& vertex) const
  {
    size_t vertex_len = vertex.table_size();
    constexpr unsigned min_size = OT::ClassDefFormat1_3<SmallTypes>::min_size;
    if (unlikely (vertex_len < min_size)) return Err(SANITIZE_FAILURE);
    hb_barrier ();
    if (unlikely (vertex_len < min_size + classValue.get_size () - classValue.len.get_size ()))
      return Err(SANITIZE_FAILURE);
    return Ok();
  }
};

struct ClassDefFormat2 : public OT::ClassDefFormat2_4<SmallTypes>
{
  graph_result_t<void> sanitize (const graph_t::vertex_t& vertex) const
  {
    size_t vertex_len = vertex.table_size();
    constexpr unsigned min_size = OT::ClassDefFormat2_4<SmallTypes>::min_size;
    if (unlikely (vertex_len < min_size)) return Err(SANITIZE_FAILURE);
    hb_barrier ();
    if (unlikely (vertex_len < min_size + rangeRecord.get_size () - rangeRecord.len.get_size ()))
      return Err(SANITIZE_FAILURE);
    return Ok();
  }
};

struct ClassDef : public OT::ClassDef
{
  template<typename It>
  static graph_result_t<void> add_class_def (gsubgpos_graph_context_t& c,
                                             unsigned parent_id,
                                             unsigned link_position,
                                             It glyph_and_class,
                                             unsigned max_size)
  {
    TRY_ASSIGN (unsigned class_def_prime_id, c.graph.new_node (nullptr, nullptr));
    auto& class_def_prime_vertex = c.graph.vertices_[class_def_prime_id];
    TRY (make_class_def (c, glyph_and_class, class_def_prime_id, max_size));

    TRY(c.graph.vertices_[parent_id].add_real_link (SmallTypes::size, class_def_prime_id, link_position));
    TRY(class_def_prime_vertex.add_parent (parent_id, false));

    return Ok();
  }

  template<typename It>
  static graph_result_t<void> make_class_def (gsubgpos_graph_context_t& c,
                                              It glyph_and_class,
                                              unsigned dest_obj,
                                              unsigned max_size)
  {
    char* buffer = (char*) hb_calloc (1, max_size);
    if (unlikely (!buffer))
      return Err(ALLOCATION_FAILURE);

    hb_serialize_context_t serializer (buffer, max_size);
    OT::ClassDef_serialize (&serializer, glyph_and_class);
    serializer.end_serialize ();
    if (unlikely (serializer.in_error ()))
    {
      hb_free (buffer);
      return Err(ALLOCATION_FAILURE);
    }

    hb_bytes_t class_def_copy = serializer.copy_bytes ();
    if (unlikely (!class_def_copy.arrayZ))
    {
      hb_free (buffer);
      return Err(ALLOCATION_FAILURE);
    }

    // Give ownership to the context, it will cleanup the buffer.
    auto res = c.add_buffer ((char *) class_def_copy.arrayZ);
    if (unlikely (!res.is_ok ()))
    {
      hb_free (buffer);
      hb_free ((char *) class_def_copy.arrayZ);
      return res;
    }


    auto& v = c.graph.vertices_[dest_obj];
    char* head = (char *) class_def_copy.arrayZ;
    v.set_buffer (head, head + class_def_copy.length);

    hb_free (buffer);
    return Ok();
  }

  graph_result_t<void> sanitize (const graph_t::vertex_t& vertex) const
  {
    size_t vertex_len = vertex.table_size();
    if (unlikely (vertex_len < OT::ClassDef::min_size)) return Err(SANITIZE_FAILURE);
    hb_barrier ();
    switch (u.format.v)
    {
    case 1: return ((ClassDefFormat1*)this)->sanitize (vertex);
    case 2: return ((ClassDefFormat2*)this)->sanitize (vertex);
#ifndef HB_NO_BEYOND_64K
    // Not currently supported
    case 3:
    case 4:
#endif
    default: return Err(SANITIZE_FAILURE);
    }
  }
};


struct class_def_size_estimator_t
{
  // TODO(garretrieger): update to support beyond64k coverage/classdef tables.
  constexpr static unsigned class_def_format1_base_size = 6;
  constexpr static unsigned class_def_format2_base_size = 4;
  constexpr static unsigned coverage_base_size = 4;
  constexpr static unsigned bytes_per_range = 6;
  constexpr static unsigned bytes_per_glyph = 2;

  template<typename It>
  static graph_result_t<class_def_size_estimator_t> create (It glyph_and_class)
  {
    class_def_size_estimator_t estimator;
    estimator.reset();
    for (auto p : + glyph_and_class)
    {
      unsigned gid = p.first;
      unsigned klass = p.second;

      hb_set_t* glyphs;
      if (estimator.glyphs_per_class.has (klass, &glyphs) && glyphs) {
        glyphs->add (gid);
        continue;
      }

      hb_set_t new_glyphs;
      new_glyphs.add (gid);
      estimator.glyphs_per_class.set (klass, std::move (new_glyphs));
    }

    TRY(estimator.to_result ());

    for (unsigned klass : estimator.glyphs_per_class.keys ())
    {
      if (!klass) continue; // class 0 doesn't get encoded.

      const hb_set_t& glyphs = estimator.glyphs_per_class.get (klass);
      hb_codepoint_t start = HB_SET_VALUE_INVALID;
      hb_codepoint_t end = HB_SET_VALUE_INVALID;

      unsigned count = 0;
      while (glyphs.next_range (&start, &end))
        count++;

      estimator.num_ranges_per_class.set (klass, count);
    }

    TRY(estimator.to_result ());
    return estimator;
  }

  void reset() {
    class_def_1_size = class_def_format1_base_size;
    class_def_2_size = class_def_format2_base_size;
    coverage_size_val = coverage_base_size;
    included_glyphs.clear();
    included_classes.clear();
  }

  // Size of coverage for all glyphs added via 'add_class_def_size'.
  unsigned coverage_size () const
  {
    return coverage_size_val;
  }

  // Compute the new size of the ClassDef table if all glyphs associated with 'klass' were added.
  unsigned add_class_def_size (unsigned klass)
  {
    if (!included_classes.has(klass)) {
      hb_set_t* glyphs = nullptr;
      if (glyphs_per_class.has(klass, &glyphs)) {
        unsigned num_glyphs = included_glyphs.get_population();
        included_glyphs.union_(*glyphs);
        if (num_glyphs != included_glyphs.get_population())
          coverage_size_val = compute_coverage_size ();
      }

      class_def_1_size = class_def_format1_base_size;
      if (!included_glyphs.is_empty()) {
        unsigned min_glyph = included_glyphs.get_min();
        unsigned max_glyph = included_glyphs.get_max();
        class_def_1_size += bytes_per_glyph * (max_glyph - min_glyph + 1);
      }

      class_def_2_size += bytes_per_range * num_ranges_per_class.get (klass);

      included_classes.add(klass);
    }

    return hb_min (class_def_1_size, class_def_2_size);
  }

  unsigned num_glyph_ranges() const {
    hb_codepoint_t start = HB_SET_VALUE_INVALID;
    hb_codepoint_t end = HB_SET_VALUE_INVALID;

    unsigned count = 0;
    while (included_glyphs.next_range (&start, &end)) {
        count++;
    }
    return count;
  }

 private:
  graph_result_t<void> to_result() const
  {
    TRY (graph_result_t<void>::from (num_ranges_per_class, ALLOCATION_FAILURE));
    TRY (graph_result_t<void>::from (glyphs_per_class, ALLOCATION_FAILURE));

    for (const hb_set_t& s : glyphs_per_class.values ())
    {
          TRY (graph_result_t<void>::from (s, ALLOCATION_FAILURE));
    }
    return Ok();
  }

  class_def_size_estimator_t ()
      : num_ranges_per_class (), glyphs_per_class () {}

  unsigned compute_coverage_size () const
  {
    unsigned format1_size = coverage_base_size + bytes_per_glyph * included_glyphs.get_population();
    unsigned format2_size = coverage_base_size + bytes_per_range * num_glyph_ranges();
    return hb_min(format1_size, format2_size);
  }

  hb_hashmap_t<unsigned, unsigned> num_ranges_per_class;
  hb_hashmap_t<unsigned, hb_set_t> glyphs_per_class;
  hb_set_t included_classes;
  hb_set_t included_glyphs;
  unsigned class_def_1_size;
  unsigned class_def_2_size;
  unsigned coverage_size_val;
};


}

#endif  // GRAPH_CLASSDEF_GRAPH_HH
